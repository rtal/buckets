Running the app
===

Try installing the .ipa file directly to your device.
* Connect your phone to your computer
* open up itunes
* drag the .ipa file int your apps

If that doesn't work, download the code from bit.ly/bucketshifi2
* Open up bucektsO.xcworkspace in xcode
* Make sure you open the .xcworkspace, not the xcodeproj
* Run on simulator or device
