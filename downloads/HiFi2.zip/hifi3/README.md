Running the Buckets App
==

.IPA
---
Install the .ipa file directly to your device.
* Your device must be registered with Stanford's CS Department iOS Team
* Connect your phone to your computer
* open up iTunes
* drag the .ipa file int your apps

Xcode Build
---
OR if that doesn't work, download the code from bit.ly/bucketshifi2
* Open up bucketsO.xcworkspace in xcode
* Make sure you open the .xcworkspace, not the xcodeproj
* Run on simulator or device

TestFlight
---
OR email me@andrewbfang.com for a TestFlight invitation
* Please wait 3-5 days for processing
